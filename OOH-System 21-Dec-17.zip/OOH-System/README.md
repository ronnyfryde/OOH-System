# OOH-System
A basic out of hours system for managing first line and escalation support engineers.
